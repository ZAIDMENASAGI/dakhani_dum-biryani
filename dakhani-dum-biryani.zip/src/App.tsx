import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Phone, 
  MapPin, 
  Star, 
  Utensils, 
  ChevronRight, 
  ShoppingBag, 
  Plus, 
  Minus, 
  Trash2, 
  Truck, 
  X 
} from 'lucide-react';
import { MENU_DATA, REVIEWS_DATA, type MenuItem, type Review } from './types';

// --- Cart Component ---

const OrderModal = ({ 
  isOpen, 
  onClose, 
  cart, 
  onUpdateQuantity, 
  onRemove 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  cart: { item: MenuItem; quantity: number }[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemove: (id: string) => void;
}) => {
  const total = cart.reduce((sum, entry) => {
    const priceStr = entry.item.price.replace('₹', '');
    const priceNum = parseInt(priceStr);
    if (isNaN(priceNum)) return sum;
    return sum + (priceNum * entry.quantity);
  }, 0);

  const sendOrder = () => {
    const itemsText = cart.map(e => `- ${e.item.name} x${e.quantity} (${e.item.price})`).join('\n');
    const message = `Hello Dakhani Dum Biryani! I would like to place an order for delivery:\n\n${itemsText}\n\nTotal: ₹${total}\n\nPlease confirm my order. Thank you!`;
    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/918073830698?text=${encoded}`, '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        onClick={onClose}
        className="absolute inset-0 bg-brand-dark/80 backdrop-blur-sm" 
      />
      <motion.div 
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl"
      >
        <div className="p-6 border-b border-gray-100 flex justify-between items-center">
          <h2 className="text-2xl font-extrabold tracking-tight">MY ORDER</h2>
          <button onClick={onClose} className="p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"><X size={20} /></button>
        </div>

        <div className="p-6 max-h-[50vh] overflow-y-auto">
          {cart.length === 0 ? (
            <div className="text-center py-12">
              <div className="bg-gray-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-dashed border-gray-200">
                <ShoppingBag className="text-gray-300" size={32} />
              </div>
              <p className="text-gray-400 font-medium">Your cart is empty.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.map(entry => (
                <div key={entry.item.id} className="flex gap-4 items-center bg-gray-50 p-4 rounded-2xl border border-gray-100">
                  <div className="flex-1">
                    <h4 className="font-bold text-lg">{entry.item.name}</h4>
                    <p className="text-sm font-semibold text-brand-red">{entry.item.price}</p>
                  </div>
                  <div className="flex items-center gap-3 bg-white px-3 py-1.5 rounded-xl shadow-sm">
                    <button onClick={() => onUpdateQuantity(entry.item.id, -1)} className="hover:text-brand-red p-1"><Minus size={14} /></button>
                    <span className="text-sm font-black min-w-[1.2rem] text-center">{entry.quantity}</span>
                    <button onClick={() => onUpdateQuantity(entry.item.id, 1)} className="hover:text-brand-red p-1"><Plus size={14} /></button>
                  </div>
                  <button onClick={() => onRemove(entry.item.id)} className="text-gray-300 hover:text-red-500 transition-colors"><Trash2 size={18} /></button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="p-6 bg-white border-t border-gray-100 shadow-[0_-10px_40px_rgba(0,0,0,0.02)]">
          <div className="flex justify-between items-center mb-6">
            <div>
              <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest mb-1">Grand Total</p>
              <p className="text-3xl font-black text-brand-dark">₹{total}</p>
            </div>
            <div className="bg-green-50 px-4 py-2 rounded-xl flex items-center gap-2 border border-green-100">
               <Truck size={16} className="text-green-600" />
               <div className="text-left">
                 <p className="text-[10px] font-black text-green-700 uppercase tracking-tighter leading-none">FREE DELIVERY</p>
                 <p className="text-[9px] text-green-600 font-medium">Within Dharwad</p>
               </div>
            </div>
          </div>
          <button 
            disabled={cart.length === 0}
            onClick={sendOrder}
            className="w-full btn-primary py-4 rounded-2xl flex items-center justify-center gap-3 group"
          >
            SEND ORDER TO KITCHEN <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [activeCategory, setActiveCategory] = useState<'Biryani' | 'Starters' | 'Drinks' | 'Party Orders'>('Biryani');
  const [cart, setCart] = useState<{ item: MenuItem; quantity: number }[]>([]);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.item.id === item.id);
      if (existing) {
        return prev.map(i => i.item.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { item, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.item.id === id) {
        const newQty = i.quantity + delta;
        return { ...i, quantity: Math.max(1, newQty) };
      }
      return i;
    }));
  };

  const removeItem = (id: string) => {
    setCart(prev => prev.filter(i => i.item.id !== id));
  };

  const cartCount = cart.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <div className="min-h-screen relative font-sans">
      {/* Floating Action Button - Fast Food Style */}
      <AnimatePresence>
        {cartCount > 0 && (
          <motion.button
            initial={{ scale: 0, y: 100 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0, y: 100 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsOrderModalOpen(true)}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[80] btn-primary flex items-center gap-4 px-8 py-4 shadow-2xl"
          >
            <div className="bg-white/20 px-2 py-0.5 rounded-lg text-xs font-black">
              {cartCount}
            </div>
            <span className="font-extrabold tracking-tight">VIEW YOUR ORDER</span>
            <ShoppingBag size={20} />
          </motion.button>
        )}
      </AnimatePresence>

      <OrderModal 
        isOpen={isOrderModalOpen} 
        onClose={() => setIsOrderModalOpen(false)}
        cart={cart}
        onUpdateQuantity={updateQuantity}
        onRemove={removeItem}
      />

      {/* Dynamic Header */}
      <header className="sticky top-0 z-50 bg-white shadow-sm border-b border-gray-100">
        <div className="section-container h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-12 h-12 brand-gradient rounded-xl flex items-center justify-center text-white shadow-lg">
              <Utensils size={24} strokeWidth={3} />
            </div>
            <div>
              <h1 className="text-xl font-black leading-none text-brand-dark">DAKHANI</h1>
              <p className="text-[10px] font-black tracking-[0.2em] text-brand-red">DUM BIRYANI</p>
            </div>
          </div>

          <nav className="hidden lg:flex items-center gap-8">
            {['Home', 'About', 'Menu', 'Reviews', 'Contact'].map((item) => (
              <a key={item} href={`#${item.toLowerCase()}`} className="text-sm font-bold text-gray-500 hover:text-brand-red transition-colors">
                {item}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-4">
             <a href="tel:08073830698" className="hidden sm:flex items-center gap-2 bg-brand-red/5 text-brand-red px-4 py-2 rounded-xl text-sm font-extrabold hover:bg-brand-red/10 transition-all border border-brand-red/10">
               <Phone size={14} /> 080738 30698
             </a>
             <button onClick={() => setIsOrderModalOpen(true)} className="relative p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                <ShoppingBag size={22} className="text-gray-700" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-brand-red text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">
                    {cartCount}
                  </span>
                )}
             </button>
          </div>
        </div>
      </header>

      {/* Hero: High Energy Fast Food Style */}
      <section id="home" className="relative pt-12 pb-24 overflow-hidden bg-white">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-dark/5 skew-x-12 translate-x-1/4 -z-10" />
        
        <div className="section-container grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 bg-brand-red/10 text-brand-red px-4 py-2 rounded-full mb-6">
              <Truck size={14} />
              <span className="text-xs font-black uppercase tracking-widest">Free Home Delivery</span>
            </div>
            
            <h1 className="text-6xl lg:text-8xl font-black leading-[0.9] text-brand-dark mb-6">
               HOT. FRESH. <br />
               <span className="text-brand-red">DELICIOUS.</span>
            </h1>
            
            <p className="text-xl text-gray-500 font-medium leading-relaxed max-w-lg mb-10">
               Authentic Dakhani Dum Biryani served with love. Experience the royal taste of Dharwad in every bite!
            </p>

            <div className="flex flex-wrap gap-4 items-center">
              <a href="#menu" className="btn-primary flex items-center gap-2">
                ORDER NOW <ChevronRight size={18} />
              </a>
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <div className="flex -space-x-3">
                  {[1,2,3].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full bg-gray-200 border-2 border-white flex items-center justify-center text-[10px] font-black">
                      <Star size={10} className="fill-brand-red text-brand-red" />
                    </div>
                  ))}
                </div>
                <div>
                  <p className="text-sm font-black">5.0 RATING</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">on Google Reviews</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 0.8, type: 'spring' }}
            className="relative"
          >
            <div className="brand-gradient absolute inset-0 rounded-[4rem] rotate-6 transform scale-95 opacity-20" />
            <img 
              src="https://lh3.googleusercontent.com/p/AF1QipMZp9Adv58OPh5rcQlasnZg4Cos3dRszQpMYyYH=s1000"
              alt="Dakhani Dum Biryani"
              className="relative z-10 w-full rounded-[4rem] shadow-2xl border-8 border-white object-cover aspect-video sm:aspect-square"
              referrerPolicy="no-referrer"
            />
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-3xl shadow-xl z-20 border border-gray-100 flex items-center gap-4">
               <div className="w-12 h-12 brand-gradient rounded-full flex items-center justify-center text-white">
                 <Truck size={24} />
               </div>
               <div>
                 <p className="text-xs font-black text-gray-400">ARRIVES IN</p>
                 <p className="text-xl font-black text-brand-dark underline decoration-brand-red decoration-4 underline-offset-4">30 MINS</p>
               </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Section - Modernized */}
      <section id="about" className="py-24 bg-brand-gray">
        <div className="section-container">
          <div className="bg-white rounded-[3rem] p-12 lg:p-20 shadow-xl border border-gray-100 flex flex-col lg:flex-row gap-16 items-center">
            <div className="flex-1">
              <span className="text-brand-red font-black uppercase tracking-[0.3em] text-[10px] mb-4 block">Our Story</span>
              <h2 className="text-4xl md:text-5xl font-black text-brand-dark mb-8 leading-tight">
                Crafting the Perfect <br />
                <span className="text-brand-red">Dakhani Tradition</span>
              </h2>
              <p className="text-lg text-gray-600 font-medium leading-relaxed mb-6">
                Founded on **May 18, 2025**, we've brought the secret spices of the Deccan to Dharwad. We don't just cook biryani; we slow-cook happiness in every 'handi'.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-gray-50 p-4 rounded-2xl">
                  <h3 className="text-2xl font-black text-brand-red">100%</h3>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Fresh Ingredients</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-2xl">
                  <h3 className="text-2xl font-black text-brand-dark">DECCAN</h3>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Authentic Recipes</p>
                </div>
              </div>
            </div>
            <div className="flex-1 w-full grid grid-cols-2 gap-4">
              <img src="https://lh3.googleusercontent.com/p/AF1QipM1OwGNm3PE5mSbUGByrxa3vJtQjBG4zj9cUuTo=s800" className="rounded-2xl w-full h-48 object-cover shadow-lg" referrerPolicy="no-referrer" />
              <img src="https://picsum.photos/seed/dakhani-interior/400/600" className="rounded-2xl w-full h-48 object-cover shadow-lg mt-8" referrerPolicy="no-referrer" />
              <img src="https://lh3.googleusercontent.com/p/AF1QipOAqvQbn1ldpmrqZba21v3Ifdtb9crc90C00xAh=s800" className="rounded-2xl w-full h-48 object-cover shadow-lg -mt-8" referrerPolicy="no-referrer" />
              <img src="https://picsum.photos/seed/dakhani-spices/400/600" className="rounded-2xl w-full h-48 object-cover shadow-lg" referrerPolicy="no-referrer" />
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section - Fast Food Dashboard Style */}
      <section id="menu" className="py-24 bg-white">
        <div className="section-container">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-8">
            <div className="text-center md:text-left">
              <h2 className="text-5xl font-black text-brand-dark mb-4 tracking-tighter italic underline decoration-brand-red decoration-8 underline-offset-8">THE MENU</h2>
              <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Fresh from the kitchen to your door</p>
            </div>
            
            <div className="flex bg-gray-100 p-2 rounded-2xl overflow-x-auto no-scrollbar max-w-full">
              {(['Biryani', 'Starters', 'Drinks', 'Party Orders'] as const).map(cat => (
                <button 
                  key={cat}
                  onClick={() => setActiveCategory(cat as any)}
                  className={`nav-pill ${activeCategory === cat ? 'bg-brand-red text-white shadow-lg' : 'text-gray-400 hover:text-brand-dark'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {MENU_DATA.filter(i => i.category === activeCategory).map(item => (
              <motion.div 
                layout
                key={item.id}
                className="food-card p-6"
              >
                {item.isSignature && (
                  <div className="bg-brand-yellow text-brand-dark text-[10px] font-black px-3 py-1 rounded-full w-fit mb-4 flex items-center gap-1">
                    <Star size={10} className="fill-current" /> SIGNATURE
                  </div>
                )}
                <div className="flex-1">
                  <h3 className="text-2xl font-black leading-none mb-3 group-hover:text-brand-red transition-colors">{item.name}</h3>
                  <p className="text-sm font-medium text-gray-400 line-clamp-2 mb-6">{item.description}</p>
                </div>
                
                <div className="flex items-center justify-between mt-auto pt-6 border-t border-gray-50">
                  <div>
                    <p className="text-[10px] font-black text-gray-300 uppercase leading-none mb-1">Price</p>
                    <p className="text-2xl font-black text-brand-dark">{item.price}</p>
                  </div>
                  <motion.button 
                    whileTap={{ scale: 0.9 }}
                    onClick={() => addToCart(item)}
                    className="w-12 h-12 bg-brand-red text-white rounded-xl flex items-center justify-center shadow-lg shadow-brand-red/30 hover:bg-brand-dark transition-colors"
                  >
                    <Plus size={24} strokeWidth={3} />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews - Grid Style */}
      <section id="reviews" className="py-24 bg-brand-gray">
        <div className="section-container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black italic mb-4">CUSTOMER SMILES</h2>
            <div className="flex justify-center gap-1">
              {[1,2,3,4,5].map(i => <Star key={i} size={20} className="fill-brand-red text-brand-red" />)}
            </div>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {REVIEWS_DATA.map(review => (
              <div key={review.id} className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 relative pt-12">
                <div className="absolute top-0 left-8 -translate-y-1/2 w-12 h-12 brand-gradient rounded-2xl flex items-center justify-center text-white text-2xl font-black italic">
                  "
                </div>
                <p className="text-lg font-bold text-gray-700 leading-relaxed mb-8 italic">
                  {review.comment}
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center font-black text-xs">
                    {review.author[0]}
                  </div>
                  <div>
                    <p className="text-sm font-black">{review.author}</p>
                    <p className="text-[10px] text-brand-red font-black uppercase tracking-widest">Verified Guest</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact & MapSection */}
      <footer id="contact" className="bg-brand-dark text-white pt-24 pb-12">
        <div className="section-container">
          <div className="grid lg:grid-cols-4 gap-12 mb-20">
            <div className="lg:col-span-2">
              <h2 className="text-4xl font-black mb-8 italic text-brand-red underline decoration-brand-red decoration-4 underline-offset-8">ORDER TODAY.</h2>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
                      <MapPin size={20} className="text-brand-red" />
                    </div>
                    <p className="text-sm font-bold opacity-70">2nd Cross, behind ICICI Bank, Y.S. Colony, Dharwad 580004</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
                      <Phone size={20} className="text-brand-red" />
                    </div>
                    <p className="text-2xl font-black">080738 30698</p>
                  </div>
                  <div className="flex gap-4">
                    <a href="https://wa.me/918073830698" className="btn-secondary py-3 px-6 text-xs font-black">WHATSAPP</a>
                    <a href="tel:08073830698" className="btn-primary py-3 px-6 text-xs font-black">CALL SHOP</a>
                  </div>
                </div>
                <div className="rounded-3xl overflow-hidden border-4 border-white/10 shadow-2xl h-48 md:h-full min-h-[200px]">
                  <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d123048.24354228!2d74.939223!3d15.4589!2m3!1f0!2f0!3f0!3m2!1i1024!2i1024!4f13.1!3m3!1m2!1s0x3bb8d72dfd9f8295%3A0xe5f9b9f8f9b9f8f9!2sDakhani%20Dum%20Biryani!5e0!3m2!1sen!2sin!4v1713289000000!5m2!1sen!2sin" 
                    width="100%" 
                    height="100%" 
                    style={{ border: 0 }} 
                    allowFullScreen 
                    loading="lazy" 
                  />
                </div>
              </div>
            </div>
            
            <div className="flex flex-col justify-end">
              <p className="text-brand-red font-black text-xs uppercase tracking-widest mb-4">Operating Hours</p>
              <p className="text-2xl font-black mb-1">12:30 PM – 10:30 PM</p>
              <p className="text-sm font-bold opacity-40">Open Daily for Fresh Service</p>
            </div>
            
            <div className="flex flex-col justify-end">
               <p className="text-brand-red font-black text-xs uppercase tracking-widest mb-4">Follow Us</p>
               <div className="flex gap-4">
                  {['INSTAGRAM', 'FACEBOOK'].map(social => (
                    <a key={social} href="#" className="font-black text-xs hover:text-brand-red transition-colors underline decoration-2 underline-offset-4">{social}</a>
                  ))}
               </div>
            </div>
          </div>

          <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
             <div className="flex items-center gap-2">
                <div className="w-8 h-8 brand-gradient rounded-lg flex items-center justify-center text-white">
                  <Utensils size={14} />
                </div>
                <p className="text-[10px] font-black tracking-widest opacity-30 italic">© 2025 DAKHANI DUM BIRYANI | DHARWAD</p>
             </div>
             <div className="flex gap-8 text-[10px] font-black tracking-widest opacity-30">
                <a href="#" className="hover:opacity-100 transition-all">PRIVACY POLICY</a>
                <a href="#" className="hover:opacity-100 transition-all">TERMS OF SERVICE</a>
             </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
