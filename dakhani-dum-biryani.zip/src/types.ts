export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: string;
  category: 'Biryani' | 'Starters' | 'Sides' | 'Drinks' | 'Party Orders';
  isSignature?: boolean;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
}

export const MENU_DATA: MenuItem[] = [
  {
    id: 'b1_full',
    name: 'Chicken Biryani (Full)',
    description: 'Authentic Dakhani style chicken dum biryani, full serving.',
    price: '₹130',
    category: 'Biryani',
    isSignature: true,
  },
  {
    id: 'b1_half',
    name: 'Chicken Biryani (Half)',
    description: 'Authentic Dakhani style chicken dum biryani, half serving.',
    price: '₹80',
    category: 'Biryani',
  },
  {
    id: 's1_full',
    name: 'Chicken Juicy Kabab (Full)',
    description: 'Succulent and perfectly spiced juicy chicken kababs, full serving.',
    price: '₹130',
    category: 'Starters',
    isSignature: true,
  },
  {
    id: 's1_half',
    name: 'Chicken Juicy Kabab (Half)',
    description: 'Succulent and perfectly spiced juicy chicken kababs, half serving.',
    price: '₹80',
    category: 'Starters',
  },
  {
    id: 'p1',
    name: 'Chicken Biryani (Party Order)',
    description: 'Bulk order for parties and events. Authentic taste in large quantities. Only on orders.',
    price: 'Contact for Price',
    category: 'Party Orders',
  },
  {
    id: 'p2',
    name: 'Mutton Biryani (Party Order)',
    description: 'Premium mutton biryani for special occasions. Only on orders.',
    price: 'Contact for Price',
    category: 'Party Orders',
  },
  {
    id: 'd1',
    name: 'Campa Cola',
    description: 'The Great Indian Taste - Original Cola Flavour.',
    price: '₹20',
    category: 'Drinks',
  },
  {
    id: 'd2',
    name: 'Campa Orange',
    description: 'Refreshing Orange fizz.',
    price: '₹20',
    category: 'Drinks',
  },
  {
    id: 'd3',
    name: 'Campa Lemon',
    description: 'Zesty Lemon lime refresher.',
    price: '₹20',
    category: 'Drinks',
  },
];

export const REVIEWS_DATA: Review[] = [
  {
    id: 'r1',
    author: 'Rahul Deshpande',
    rating: 5,
    comment: "It’s not just food, it’s pure happiness served on a plate!",
  },
  {
    id: 'r2',
    author: 'Priya Kulkarni',
    rating: 5,
    comment: "Delicious Biriyani and good service with cleanness. The authentic Dakhani taste is hard to find elsewhere.",
  },
  {
    id: 'r3',
    author: 'Anand Hegde',
    rating: 5,
    comment: "The rice was perfect, taste was too good and place was very neat and clean. Highly recommended!",
  },
];
